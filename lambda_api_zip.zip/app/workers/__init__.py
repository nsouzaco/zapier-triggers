"""Background workers for event processing."""

