"""
Zapier Triggers API

A unified, event-driven API for triggering Zapier workflows in real-time.
"""

__version__ = "1.0.0"

