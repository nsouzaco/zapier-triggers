"""Core business logic and middleware."""

